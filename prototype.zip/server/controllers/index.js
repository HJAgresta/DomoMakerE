module.exports.Account = require('./Account.js');
module.exports.Fighter = require('./Fighter.js');
